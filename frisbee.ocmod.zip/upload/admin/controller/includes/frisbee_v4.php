<?php

namespace Opencart\Application\Controller\Extension\Frisbee\Payment;

class Frisbee extends \ControllerPaymentFrisbee {}

