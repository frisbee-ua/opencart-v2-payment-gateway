<?php

namespace Opencart\Application\Controller\Extension\Frisbee\Payment;

if (!class_exists('Controller')) {
    class Controller extends \Opencart\System\Engine\Controller {}
}

class Frisbee extends ControllerPaymentFrisbee {}

?>
